import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import WelcomeSection from '../WelcomeSection';

function Home(){
    return(
        <div>
            <WelcomeSection />
        </div>
    )
}

export default Home;