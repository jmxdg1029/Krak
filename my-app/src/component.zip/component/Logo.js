import React from 'react';
import {AnimateGroup, Animate, Component, useAnimateGroup} from 'react-simple-animate/dist/'
import '../component/Logo.css'

export default function Logo() {
     
    const items = ['R', 'E', 'A', 'C', 'T'];
    const { styles, play } = useAnimateGroup({
        iterationCount: 'infinite',
        direction: 'alternate',
        duration: 5,
    sequences: items.map(() => ({
        start: { opacity: 1, transform: 'translateY(0)' },
        end: { opacity: 0, transform: 'translateY(-10px)' }
    }))
    })

    return(
        <>
        {items.map((item, index) => <div key={item} style={styles[index]}>{item}</div>)}
        </>
    );

}
 


