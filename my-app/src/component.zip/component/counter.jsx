import React, {Component} from 'react';


class Counter extends React.Component{
    state = {
        value: this.props.value
    }

   
    increaseleIncrement = () => {
        this.setState({value: this.state.value + 1})
    }

    decreaseIncrement = () => {
        this.state.value != 0 ? this.setState({value: this.state.value - 1}) : this.setState({value: 0})
    }

    render()
    {
        console.log('props', this.props);

        return(
        <React.Fragment>
            <span className={this.counterClass()}>{this.frameCounter()}</span>
            <button onClick={this.increaseleIncrement}>+</button>
            <button onClick={this.decreaseIncrement}>-</button>
        </React.Fragment>);
        
    }

    counterClass(){
        let counterclass = "badge m-2 badge-";
        counterclass += this.state.value === 0 ? 'warning' : 'primary';
        return counterclass;
    }

    frameCounter()
    {
        return this.state.value === 0 ? 'Zero' : this.state.value;
    }
}

export default Counter;