import React from 'react';
import CardDeck from 'react-bootstrap/CardDeck';
import Card from 'react-bootstrap/Card';
import img1 from '../component/images/post.png';
import img2 from '../component/images/web2.jpg';
import Carousel from 'react-bootstrap/Carousel';


function Carditem(){
    return ( 
        <div className="container-fluid mx-auto text-center" alt="Responsive image"> 
           <h1 className="text-white b">Post Snippets of your Website </h1>
            <div className="mt-5 container" >   
                    <div className='row mt-4'>
                <CardDeck >
                <div className="col ">
                        <Card >
                            <Card.Img  src={img1} />
                                <Card.Body>
                                <Card.Title>Contagion</Card.Title>
                                <Card.Text>Just made this Project out of ReactJS and Bootstrap !! Can't wait to publish this online. Check my profile to download the folder</Card.Text>
                            </Card.Body>
                            <Card.Footer>2 days ago</Card.Footer>
                        </Card>
                </div>
                <div className="col">
                        <Card >
                            <Card.Img  src={img2} />
                                <Card.Body>
                                <Card.Title>Contagion</Card.Title>
                                <Card.Text>A website for users to list items to sell and have other users buy products and delivered</Card.Text>
                            </Card.Body>
                            <Card.Footer>3 hours ago</Card.Footer>
                        </Card>
                </div>
                
                </CardDeck>
                </div>
            </div>
        </div>
     );
}

 
export default Carditem;